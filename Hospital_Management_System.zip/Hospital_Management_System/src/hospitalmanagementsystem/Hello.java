package Finalprojectjava;

	public interface Hello {
	    public void print();
	    public void welcome();
	}

