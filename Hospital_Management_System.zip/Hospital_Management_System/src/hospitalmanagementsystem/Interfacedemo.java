package Finalprojectjava;

	public class Interfacedemo implements Hello, Welcome {
	    public void print() {
	        System.out.println("                     * * *        Welcome To       * * *");
	    }
	    public void welcome() {
	       System.out.println("                     * * *     TARULAB HOSPITAL    * * * ");
	    }
}
