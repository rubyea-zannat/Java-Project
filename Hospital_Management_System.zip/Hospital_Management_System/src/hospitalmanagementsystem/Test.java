package Finalprojectjava;

public class Test {
	public static void main(String args[])
	
	{
		Interfacedemo i = new Interfacedemo();
        i.print();
        i.welcome();
        
		Main m1 = new Main();
		m1.showMain();
	}
} 