package Finalprojectjava;
 
    public interface Welcome {
        public void print();
        public void welcome();
    }